// Spotify on Windows, through the System Media Transport Controls (SMTC): the
// session Windows shows in its media flyout. Spotify publishes its track,
// playback state, timeline and cover there, and takes play/pause, next,
// previous, seek, shuffle and repeat. SMTC has no volume: that is the
// per-application volume Windows keeps for Spotify.exe, read through Core Audio.
//
// SMTC's change events would need COM handler objects, so one thread reads the
// session instead: about once a second while Spotify plays, every three seconds
// otherwise. It runs only while the pill is declared; turning the pill off ends
// it. The island is told only what changed (a track, the status, a seek, the
// volume), and the cover is read once per track.

use std::os::windows::process::CommandExt;
use std::process::{Command, Stdio};
use std::sync::atomic::{AtomicBool, AtomicU64, Ordering};
use std::sync::Mutex;
use std::time::Duration;

use tauri::AppHandle;

use ::windows::core::{Interface, PWSTR};
use ::windows::Foundation::TimeSpan;
use ::windows::Media::Control::{
    GlobalSystemMediaTransportControlsSession as Session,
    GlobalSystemMediaTransportControlsSessionManager as Manager,
    GlobalSystemMediaTransportControlsSessionMediaProperties as MediaProperties,
    GlobalSystemMediaTransportControlsSessionPlaybackControls as Controls,
    GlobalSystemMediaTransportControlsSessionPlaybackStatus as Status,
};
use ::windows::Media::MediaPlaybackAutoRepeatMode as Repeat;
use ::windows::Storage::Streams::DataReader;
use ::windows::Win32::Foundation::CloseHandle;
use ::windows::Win32::Media::Audio::{
    eMultimedia, eRender, IAudioSessionControl2, IAudioSessionManager2, IMMDeviceEnumerator,
    ISimpleAudioVolume, MMDeviceEnumerator,
};
use ::windows::Win32::System::Com::{CoCreateInstance, CoInitializeEx, CLSCTX_ALL, COINIT_MULTITHREADED};
use ::windows::Win32::System::Threading::{
    OpenProcess, QueryFullProcessImageNameW, PROCESS_NAME_WIN32, PROCESS_QUERY_LIMITED_INFORMATION,
};

use super::{data_url, emit_state, now_ms, Artwork, PlayerState, Track, ARTWORK_EVENT, ARTWORK_LIMIT};

const CREATE_NO_WINDOW: u32 = 0x0800_0000;
/// Playing: read about once a second. Paused or closed: every three seconds.
const PLAYING_WAIT: Duration = Duration::from_secs(1);
const IDLE_WAIT: Duration = Duration::from_secs(3);
/// A position this far from where playback should be means Spotify was sought.
const SEEK_TOLERANCE: f64 = 2.0;
/// Timeline and seek values are in ticks of 100 ns.
const TICKS: f64 = 10_000_000.0;

static ACTIVE: AtomicBool = AtomicBool::new(false);
static GENERATION: AtomicU64 = AtomicU64::new(0);
static INSTALLED: AtomicBool = AtomicBool::new(false);
/// The state last sent to the island, to tell what changed.
static LAST: Mutex<Option<PlayerState>> = Mutex::new(None);

// ── Installed, opening ────────────────────────────────────────────────────────

/// Spotify registers its `spotify:` address for the user, so the key exists
/// once it is installed (the Store version included).
pub fn installed() -> bool {
    Command::new("reg")
        .args(["query", r"HKCR\spotify"])
        .creation_flags(CREATE_NO_WINDOW)
        .stdout(Stdio::null())
        .stderr(Stdio::null())
        .status()
        .map(|status| status.success())
        .unwrap_or(false)
}

/// Opens an address through the shell: `spotify:` brings Spotify forward or
/// starts it, and a web address opens the download page.
fn start(target: &str) -> bool {
    Command::new("cmd")
        .args(["/C", "start", "", target])
        .creation_flags(CREATE_NO_WINDOW)
        .stdout(Stdio::null())
        .stderr(Stdio::null())
        .spawn()
        .is_ok()
}

/// "Open Spotify": true when Spotify was reached or started; without Spotify,
/// its download page opens instead.
pub fn open() -> bool {
    if installed() {
        start("spotify:")
    } else {
        start(super::DOWNLOAD_URL);
        false
    }
}

// ── Reading Spotify ───────────────────────────────────────────────────────────

/// The Spotify session in SMTC, if it has one.
fn spotify_session() -> Option<Session> {
    let manager = Manager::RequestAsync().ok()?.get().ok()?;
    let sessions = manager.GetSessions().ok()?;
    sessions.into_iter().find(|session| {
        session
            .SourceAppUserModelId()
            .map(|id| id.to_string().to_ascii_lowercase().contains("spotify"))
            .unwrap_or(false)
    })
}

/// The cover of the track, from SMTC's thumbnail, within the size we accept.
fn cover_bytes(props: &MediaProperties) -> Option<Vec<u8>> {
    let thumbnail = props.Thumbnail().ok()?;
    let stream = thumbnail.OpenReadAsync().ok()?.get().ok()?;
    let size = stream.Size().ok()? as usize;
    if size == 0 || size > ARTWORK_LIMIT {
        return None;
    }
    let input = stream.GetInputStreamAt(0).ok()?;
    let reader = DataReader::CreateDataReader(&input).ok()?;
    reader.LoadAsync(size as u32).ok()?.get().ok()?;
    let mut bytes = vec![0u8; size];
    reader.ReadBytes(&mut bytes).ok()?;
    Some(bytes)
}

fn ticks_to_seconds(span: ::windows::core::Result<TimeSpan>) -> f64 {
    span.map(|s| s.Duration).unwrap_or(0) as f64 / TICKS
}

/// Spotify's state now, and its cover when the track changed since last time.
fn snapshot() -> (PlayerState, Option<Vec<u8>>) {
    let last = LAST.lock().unwrap().clone().unwrap_or_default();
    let installed = INSTALLED.load(Ordering::Relaxed);
    let Some(session) = spotify_session() else {
        return (PlayerState { installed, volume: last.volume, ..PlayerState::default() }, None);
    };

    let props = session.TryGetMediaPropertiesAsync().ok().and_then(|op| op.get().ok());
    let text = |get: fn(&MediaProperties) -> ::windows::core::Result<::windows::core::HSTRING>| {
        props.as_ref().and_then(|p| get(p).ok()).map(|s| s.to_string()).unwrap_or_default()
    };
    let title = text(|p| p.Title());
    let artist = text(|p| p.Artist());
    let album = text(|p| p.AlbumTitle());

    let (position, duration) = match session.GetTimelineProperties() {
        Ok(timeline) => {
            let start = ticks_to_seconds(timeline.StartTime());
            let end = ticks_to_seconds(timeline.EndTime());
            let now = ticks_to_seconds(timeline.Position());
            ((now - start).max(0.0), (end - start).max(0.0))
        }
        Err(_) => (0.0, 0.0),
    };

    let info = session.GetPlaybackInfo().ok();
    let playing = info
        .as_ref()
        .and_then(|i| i.PlaybackStatus().ok())
        .map_or(false, |status| status == Status::Playing);
    let shuffle = info
        .as_ref()
        .and_then(|i| i.IsShuffleActive().ok())
        .and_then(|flag| flag.Value().ok())
        .unwrap_or(false);
    let repeat = info
        .as_ref()
        .and_then(|i| i.AutoRepeatMode().ok())
        .and_then(|mode| mode.Value().ok())
        .map_or(false, |mode| mode != Repeat::None);

    let track = (!title.is_empty()).then(|| {
        // SMTC has no Spotify track URI: title and artist identify the track.
        let id = format!("smtc:{artist}|{title}");
        Track {
            art_url: Some(id.clone()),
            id,
            title: title.clone(),
            artist: artist.clone(),
            album: album.clone(),
            duration,
            object_path: String::new(),
        }
    });
    let track_changed = track.as_ref().map(|t| &t.id) != last.track.as_ref().map(|t| &t.id);
    let cover = if track_changed { props.as_ref().and_then(cover_bytes) } else { None };

    let volume = spotify_volume()
        .and_then(|vol| unsafe { vol.GetMasterVolume().ok() })
        .map(|level| (level * 100.0).round() as i32)
        .unwrap_or(last.volume);

    let state = PlayerState {
        running: true,
        installed,
        track,
        playing,
        position,
        position_at: now_ms(),
        shuffle,
        repeat,
        volume,
    };
    (state, cover)
}

// ── Volume: Spotify's session in Core Audio ───────────────────────────────────

/// Whether the process is Spotify.exe, from its image path.
fn is_spotify_process(pid: u32) -> bool {
    let Ok(handle) = (unsafe { OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, false, pid) }) else {
        return false;
    };
    let mut buffer = [0u16; 1024];
    let mut len = buffer.len() as u32;
    let read = unsafe {
        QueryFullProcessImageNameW(handle, PROCESS_NAME_WIN32, PWSTR(buffer.as_mut_ptr()), &mut len).is_ok()
    };
    let _ = unsafe { CloseHandle(handle) };
    read && String::from_utf16_lossy(&buffer[..len as usize])
        .to_ascii_lowercase()
        .ends_with("\\spotify.exe")
}

/// The audio session Windows keeps for Spotify on the default output device.
fn spotify_volume() -> Option<ISimpleAudioVolume> {
    unsafe {
        let enumerator: IMMDeviceEnumerator =
            CoCreateInstance(&MMDeviceEnumerator, None, CLSCTX_ALL).ok()?;
        let device = enumerator.GetDefaultAudioEndpoint(eRender, eMultimedia).ok()?;
        let manager: IAudioSessionManager2 = device.Activate(CLSCTX_ALL, None).ok()?;
        let sessions = manager.GetSessionEnumerator().ok()?;
        let count = sessions.GetCount().ok()?;
        for index in 0..count {
            let Ok(control) = sessions.GetSession(index) else { continue };
            let Ok(control) = control.cast::<IAudioSessionControl2>() else { continue };
            let Ok(pid) = control.GetProcessId() else { continue };
            if is_spotify_process(pid) {
                return control.cast::<ISimpleAudioVolume>().ok();
            }
        }
        None
    }
}

// ── Publishing ────────────────────────────────────────────────────────────────

/// Keeps the state and tells the island what changed. A seek that Spotify made
/// itself shows as a position that differs from the one the island extrapolates.
fn publish(app: &AppHandle, next: PlayerState, cover: Option<Vec<u8>>, force: bool) {
    let previous = {
        let mut last = LAST.lock().unwrap();
        let previous = last.clone().unwrap_or_default();
        *last = Some(next.clone());
        previous
    };
    let track_id = |s: &PlayerState| s.track.as_ref().map(|t| t.id.clone());
    let track_changed = track_id(&previous) != track_id(&next);
    let moved = !track_changed
        && next.track.is_some()
        && (previous.position_at_time(next.position_at) - next.position).abs() > SEEK_TOLERANCE;
    let changed = track_changed
        || moved
        || previous.running != next.running
        || previous.installed != next.installed
        || previous.playing != next.playing
        || previous.shuffle != next.shuffle
        || previous.repeat != next.repeat
        || previous.volume != next.volume;
    if force || changed {
        emit_state(app, &next);
    }
    if let (Some(bytes), Some(track)) = (cover, next.track.as_ref()) {
        if let (Some(data_url), Some(art_url)) = (data_url(&bytes), track.art_url.clone()) {
            use tauri::Emitter;
            let _ = app.emit_to(crate::island::WINDOW_LABEL, ARTWORK_EVENT, Artwork { art_url, data_url });
        }
    }
}

fn current(generation: u64) -> bool {
    ACTIVE.load(Ordering::SeqCst) && GENERATION.load(Ordering::SeqCst) == generation
}

fn listen(app: AppHandle, generation: u64) {
    unsafe {
        // The WinRT calls below need a COM apartment on this thread.
        let _ = CoInitializeEx(None, COINIT_MULTITHREADED);
    }
    while current(generation) {
        let (state, cover) = snapshot();
        let playing = state.playing;
        publish(&app, state, cover, false);
        std::thread::sleep(if playing { PLAYING_WAIT } else { IDLE_WAIT });
    }
}

// ── Entry points used by spotify.rs ───────────────────────────────────────────

/// Starts the reader when the pill is declared, stops it when it is not.
pub fn sync(app: &AppHandle, on: bool) {
    if ACTIVE.swap(on, Ordering::SeqCst) == on {
        return;
    }
    let generation = GENERATION.fetch_add(1, Ordering::SeqCst) + 1;
    if on {
        INSTALLED.store(installed(), Ordering::Relaxed);
        let app = app.clone();
        let spawned = std::thread::Builder::new()
            .name("coucou-spotify-smtc".into())
            .spawn(move || listen(app, generation));
        if let Err(err) = spawned {
            crate::log::line(format!("spotify: no listener thread: {err}"));
        }
    } else {
        *LAST.lock().unwrap() = None;
        let idle = PlayerState { installed: INSTALLED.load(Ordering::Relaxed), ..PlayerState::default() };
        emit_state(app, &idle);
    }
}

pub fn refresh(app: &AppHandle) -> Option<PlayerState> {
    if !ACTIVE.load(Ordering::SeqCst) {
        return None;
    }
    let (state, cover) = snapshot();
    publish(app, state.clone(), cover, true);
    Some(state)
}

/// Whether a control is offered by Spotify right now (SMTC says so per control).
fn can(controls: Option<&Controls>, check: impl FnOnce(&Controls) -> ::windows::core::Result<bool>) -> bool {
    controls.map_or(false, |c| check(c).unwrap_or(false))
}

fn session_control(session: &Session, action: &str, v: f64) -> bool {
    let controls = session.GetPlaybackInfo().ok().and_then(|i| i.Controls().ok());
    let c = controls.as_ref();
    match action {
        "playPause" if can(c, |c| c.IsPlayEnabled()) || can(c, |c| c.IsPauseEnabled()) => session
            .TryTogglePlayPauseAsync()
            .and_then(|op| op.get())
            .unwrap_or(false),
        "next" if can(c, |c| c.IsNextEnabled()) => session
            .TrySkipNextAsync()
            .and_then(|op| op.get())
            .unwrap_or(false),
        "previous" if can(c, |c| c.IsPreviousEnabled()) => session
            .TrySkipPreviousAsync()
            .and_then(|op| op.get())
            .unwrap_or(false),
        "seek" if can(c, |c| c.IsPlaybackPositionEnabled()) => session
            .TryChangePlaybackPositionAsync((v.max(0.0) * TICKS) as i64)
            .and_then(|op| op.get())
            .unwrap_or(false),
        "shuffle" if can(c, |c| c.IsShuffleEnabled()) => session
            .TryChangeShuffleActiveAsync(v != 0.0)
            .and_then(|op| op.get())
            .unwrap_or(false),
        "repeat" if can(c, |c| c.IsRepeatEnabled()) => session
            .TryChangeAutoRepeatModeAsync(if v != 0.0 { Repeat::List } else { Repeat::None })
            .and_then(|op| op.get())
            .unwrap_or(false),
        _ => false,
    }
}

/// A control from the card or the pill. Spotify's answer is read back at once.
pub fn control(app: &AppHandle, action: &str, value: Option<f64>) -> bool {
    if !ACTIVE.load(Ordering::SeqCst) {
        return false;
    }
    let v = value.unwrap_or(0.0);
    let done = if action == "volume" {
        spotify_volume().map_or(false, |vol| unsafe {
            vol.SetMasterVolume((v / 100.0).clamp(0.0, 1.0) as f32, std::ptr::null()).is_ok()
        })
    } else {
        spotify_session().map_or(false, |session| session_control(&session, action, v))
    };
    if done {
        let (state, cover) = snapshot();
        publish(app, state, cover, true);
    }
    done
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn the_commands_are_limited_to_what_spotify_offers() {
        // Pure: a control on a session that does not exist does nothing.
        assert!(!can(None, |c| c.IsPlayPauseEnabled()));
    }
}
